"""Step 3: group high site-days into candidate episodes and flag them.

Linking rule (frozen for screening; sensitivity-test later): two high site-days
belong to the same episode if their dates differ by <= 1 day and the sites are
<= 250 km apart. Episodes are the connected groups.

Flags, so a person can review each candidate:
  smoke_evidence   strong  = >= 50% of site-days under a Medium/Heavy HMS plume
                   partial = some site-days under any plume
                   none    = no plume overlap (likely local pollution)
  single_site      only one site exceeded
  long_merge       spans > 21 days, so it may be several fires chained together
  near_other       another candidate within 3 days and 800 km (may share a source)
  winter_flag      any day in Nov-Feb (inversions, wood smoke): review only
  holiday_flag     any day Jul 3-6 or Dec 30-Jan 2 (fireworks): review only
  eligible         smoke_evidence == strong and >= 3 sites (light plumes are an
                   unreliable sign of surface smoke, so they never qualify alone)
  needs_review     eligible but carries a winter, holiday or long_merge flag

Usage: python 03_episodes.py high_with_hms.csv.gz episodes.csv site_days_episode.csv.gz
"""
import sys
import numpy as np
import pandas as pd

LINK_KM, LINK_DAYS = 250, 1
h = pd.read_csv(sys.argv[1])
h["d"] = pd.to_datetime(h.date)
h = h.sort_values("d").reset_index(drop=True)

def km(lat1, lon1, lat2, lon2):
    p = np.pi / 180
    a = (np.sin((lat2 - lat1) * p / 2) ** 2 +
         np.cos(lat1 * p) * np.cos(lat2 * p) * np.sin((lon2 - lon1) * p / 2) ** 2)
    return 12742 * np.arcsin(np.sqrt(a))

parent = list(range(len(h)))
def find(i):
    while parent[i] != i:
        parent[i] = parent[parent[i]]
        i = parent[i]
    return i

day = h.d.values.astype("datetime64[D]").astype(int)
lat, lon = h.lat.values, h.lon.values
for i in range(len(h)):
    j = i + 1
    while j < len(h) and day[j] - day[i] <= LINK_DAYS:
        if km(lat[i], lon[i], lat[j], lon[j]) <= LINK_KM:
            ri, rj = find(i), find(j)
            if ri != rj:
                parent[rj] = ri
        j += 1
h["episode"] = [find(i) for i in range(len(h))]

def summarize(g):
    peak = g.loc[g.pm25.idxmax()]
    strong = (g.hms_density >= 2).mean()
    anyp = (g.hms_density >= 1).mean()
    md = g.d.dt.strftime("%m-%d")
    return pd.Series({
        "start": g.d.min().date(), "end": g.d.max().date(),
        "days": (g.d.max() - g.d.min()).days + 1,
        "region": g.region.mode().iat[0],
        "states": ", ".join(sorted(g.state.unique())),
        "n_sites": g.site.nunique(), "n_site_days": len(g),
        "peak_pm25": round(g.pm25.max(), 1), "peak_site": peak.site_name, "peak_date": peak.d.date(),
        "share_med_heavy_plume": round(strong, 2), "share_any_plume": round(anyp, 2),
        "raw_med_heavy": strong, "raw_any": anyp,
        "center_lat": round(g.lat.mean(), 2), "center_lon": round(g.lon.mean(), 2),
        "winter_flag": bool(g.d.dt.month.isin([11, 12, 1, 2]).any()),
        "holiday_flag": bool(md.isin(["07-03", "07-04", "07-05", "07-06",
                                      "12-30", "12-31", "01-01", "01-02"]).any()),
    })

ep = h.groupby("episode").apply(summarize, include_groups=False).reset_index()
# thresholds use the UNROUNDED shares; the rounded columns are for display only
ep["smoke_evidence"] = np.select([ep.raw_med_heavy >= 0.5, ep.raw_any > 0],
                                 ["strong", "partial"], "none")
ep["single_site"] = ep.n_sites == 1
ep["long_merge"] = ep.days > 21

near = []
for _, r in ep.iterrows():
    o = ep[(ep.episode != r.episode)]
    gap = (pd.to_datetime(o.start) - pd.to_datetime(r.end)).dt.days.abs().clip(lower=0)
    gap = np.minimum(gap, (pd.to_datetime(r.start) - pd.to_datetime(o.end)).dt.days.abs())
    close = (gap <= 3) & (km(r.center_lat, r.center_lon, o.center_lat, o.center_lon) <= 800)
    near.append(int(close.sum()))
ep["near_other"] = near
# Automatic screen: only strong (Medium/Heavy) plume evidence and 3+ sites pass.
# Winter, holiday, partial-plume and merge flags go to human review; they never
# exclude automatically, and never qualify a group on their own.
ep["eligible"] = (ep.smoke_evidence == "strong") & (ep.n_sites >= 3)
ep["needs_review"] = ep.eligible & (ep.winter_flag | ep.holiday_flag | ep.long_merge)
ep = ep.sort_values(["eligible", "n_site_days"], ascending=[False, False])
ep.insert(0, "episode_id", [f"E{i:03d}" for i in range(1, len(ep) + 1)])
ep.drop(columns=["episode", "raw_med_heavy", "raw_any"]).to_csv(sys.argv[2], index=False)
h.merge(ep[["episode", "episode_id"]], on="episode").drop(columns=["episode", "d"]).to_csv(
    sys.argv[3], index=False, compression="gzip")

print("candidate episodes:", len(ep))
print(ep.groupby(["region", "smoke_evidence"]).size().unstack(fill_value=0))
e = ep[ep.eligible]
print("\neligible:", len(e), "| long_merge among eligible:", int(e.long_merge.sum()),
      "| eligible with near_other > 0:", int((e.near_other > 0).sum()))
print(e.groupby([pd.to_datetime(e.start).dt.year, "region"]).size().unstack(fill_value=0))
