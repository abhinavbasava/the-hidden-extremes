"""Step 2: NOAA HMS smoke-plume overlap for every high PM2.5 site-day.

Downloads the daily HMS smoke polygon shapefile for each date with at least one
site-day >= 35.5 ug/m3, then records the densest analyst-drawn plume covering
each high site's coordinates. HMS plumes are satellite-detected and may sit
aloft, so overlap is supporting evidence of smoke, not proof of ground exposure.

Usage: python 02_hms_overlay.py site_days.csv.gz hms_cache_dir high_with_hms.csv.gz
"""
import os
import sys
import time
import urllib.request
import zipfile
import geopandas as gpd
import pandas as pd
from shapely.geometry import Point

sd_path, cache, out_path = sys.argv[1:4]
os.makedirs(cache, exist_ok=True)
URL = "https://satepsanone.nesdis.noaa.gov/pub/FIRE/web/HMS/Smoke_Polygons/Shapefile/{y}/{m}/hms_smoke{ymd}.zip"
RANK = {"Light": 1, "Medium": 2, "Heavy": 3}

d = pd.read_csv(sd_path)
high = d[d.pm25 >= 35.5].copy()
dates = sorted(high.date.unique())
print(len(high), "high site-days on", len(dates), "dates")

def plumes_for(date):
    ymd = date.replace("-", "")
    zp = os.path.join(cache, f"hms_smoke{ymd}.zip")
    if not os.path.exists(zp):
        url = URL.format(y=ymd[:4], m=ymd[4:6], ymd=ymd)
        for attempt in range(3):
            try:
                data = urllib.request.urlopen(url, timeout=60).read()
                open(zp, "wb").write(data)
                break
            except Exception as e:  # missing day or transient error
                last = e
                time.sleep(2)
        else:
            return None, f"download failed: {last}"
    try:
        with zipfile.ZipFile(zp) as z:
            shp = [n for n in z.namelist() if n.endswith(".shp")][0]
        g = gpd.read_file(f"zip://{zp}!{shp}")
        if g.crs is None:
            g = g.set_crs(4326)
        return g.to_crs(4326), None
    except Exception as e:
        return None, f"read failed: {e}"

rows = []
for i, date in enumerate(dates):
    g, err = plumes_for(date)
    sub = high[high.date == date]
    for _, r in sub.iterrows():
        dens, note = 0, err or ""
        if g is not None and len(g):
            hit = g[g.contains(Point(r.lon, r.lat))]
            if len(hit) and "Density" in hit.columns:
                dens = max(RANK.get(str(v).strip().title(), 0) for v in hit["Density"])
            elif len(hit):
                dens, note = 1, "plume without density field"
        rows.append({**r.to_dict(), "hms_density": dens, "hms_note": note})
    if i % 50 == 0:
        print(i, date, flush=True)

out = pd.DataFrame(rows)
out.to_csv(out_path, index=False, compression="gzip")
print(out.hms_density.value_counts().sort_index())
print("notes:", out.hms_note.replace("", pd.NA).dropna().value_counts().head())
