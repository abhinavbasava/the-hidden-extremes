"""Step 5: build the human review sheet that turns candidates into final episodes.

An episode is a distinct regional EXPOSURE period: one region, one stretch of
days, medium/heavy plume evidence, consistent ground measurements, and
documented smoke sources. Several fires feeding one plume over the same region
and days form ONE episode, not several.

Each partner fills the sheet independently, then the two compare. Disagreements
are settled in writing and logged.

Columns to fill for every eligible candidate:
  source_fires        named incidents or smoke source (e.g. "Canadian wildfires, Quebec")
  source_urls         agency or incident pages used (USFS, InciWeb, NIFC, state DEQ)
  ground_consistent   yes/no: do nearby monitors rise and fall together with the plume?
  decision            keep | merge_with:<episode_id> | split:<dates> | exclude
  decision_reason     one line
  reviewer_A, reviewer_B, agreement (yes/no), resolved_note

Usage: python 05_review_sheet.py episodes_with_families.csv review_sheet.csv
"""
import sys
import pandas as pd

ep = pd.read_csv(sys.argv[1])
el = ep[ep.eligible].copy()
fam_size = el.groupby("family_id").n_site_days.transform("sum")
el["family_high_site_days"] = fam_size
el["review_priority"] = pd.cut(fam_size, [0, 30, 150, 10**6], labels=["3_low", "2_medium", "1_high"])
keep = ["review_priority", "family_id", "episode_id", "region", "states", "start", "end", "days",
        "n_sites", "n_site_days", "peak_pm25", "peak_site", "peak_date",
        "share_med_heavy_plume", "winter_flag", "holiday_flag", "long_merge", "needs_review",
        "family_high_site_days"]
sheet = el[keep].sort_values(["review_priority", "family_id", "start"])
for c in ["source_fires", "source_urls", "ground_consistent", "decision", "decision_reason",
          "reviewer_A", "reviewer_B", "agreement", "resolved_note"]:
    sheet[c] = ""
sheet.to_csv(sys.argv[2], index=False)
print(len(sheet), "candidates to review;", sheet.family_id.nunique(), "families")
print(sheet.review_priority.value_counts().sort_index().to_string())
