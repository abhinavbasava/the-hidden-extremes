"""Step 4: merge eligible candidates into families, with a sensitivity table.

Families are a SCREENING device: algorithmic groups of candidates that may share
one regional smoke exposure. They are not confirmed independent wildfire events.
Final episodes come from the human review sheet (step 5).

Rule: two eligible candidates join the same family when the gap between their
date ranges is <= GAP days and their centers are <= DIST km apart.
Primary rule: 800 km, 3 days (a choice, not a standard). The script reports the
family count under four rules so the dependence on this choice stays visible.

Usage: python 04_families.py episodes.csv episodes_with_families.csv family_sensitivity.csv
"""
import sys
import numpy as np
import pandas as pd

RULES = [(250, 1), (500, 2), (800, 3), (1200, 5)]
PRIMARY = (800, 3)

ep = pd.read_csv(sys.argv[1])
el = ep[ep.eligible].reset_index(drop=True)
s, e = pd.to_datetime(el.start), pd.to_datetime(el.end)


def km(a, b, c, d):
    p = np.pi / 180
    x = np.sin((c - a) * p / 2) ** 2 + np.cos(a * p) * np.cos(c * p) * np.sin((d - b) * p / 2) ** 2
    return 12742 * np.arcsin(np.sqrt(x))


def families(dist, gap_days):
    par = list(range(len(el)))

    def find(i):
        while par[i] != i:
            par[i] = par[par[i]]
            i = par[i]
        return i

    for i in range(len(el)):
        for j in range(i + 1, len(el)):
            gap = max((s[j] - e[i]).days, (s[i] - e[j]).days, 0)
            if gap <= gap_days and km(el.center_lat[i], el.center_lon[i],
                                      el.center_lat[j], el.center_lon[j]) <= dist:
                par[find(j)] = find(i)
    return pd.Series([find(i) for i in range(len(el))])


rows = []
for dist, gap in RULES:
    fam = families(dist, gap)
    sd = el.groupby(fam).n_site_days.sum()
    rows.append({"rule": f"{dist} km, {gap} d", "families": fam.nunique(),
                 "families_10plus_high_site_days": int((sd >= 10).sum()),
                 "largest_family_share_of_high_site_days": round(sd.max() / sd.sum(), 2)})
    if (dist, gap) == PRIMARY:
        el["family_raw"] = fam

sens = pd.DataFrame(rows)
sens.to_csv(sys.argv[3], index=False)
print(sens.to_string(index=False))

order = el.groupby("family_raw").n_site_days.sum().sort_values(ascending=False).index
fid = {f: f"F{i:02d}" for i, f in enumerate(order, 1)}
el["family_id"] = el.family_raw.map(fid)
out = ep.merge(el[["episode_id", "family_id"]], on="episode_id", how="left")
out.to_csv(sys.argv[2], index=False)
print(f"\nPrimary rule {PRIMARY}: {el.family_id.nunique()} families from {len(el)} eligible candidates")
