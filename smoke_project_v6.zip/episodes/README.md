# Smoke episode screening, v2 (Nov 6, 2026)

Screening only. These are algorithmic candidates, not confirmed independent
smoke events, and no AI data has been generated.

## Reproduce from scratch

1. Download EPA AirData daily PM2.5 (parameter 88101) for 2021, 2022, 2023,
   2024, 2025 from https://aqs.epa.gov/aqsweb/airdata/download_files.html
   (`daily_88101_<year>.zip`) and unzip.
2. `python 01_site_days.py daily_88101_2021.csv ... daily_88101_2025.csv site_days.csv.gz`
   Expected: 593,849 site-days, 431 sites.
3. `python 02_hms_overlay.py site_days.csv.gz hms_cache/ high_with_hms.csv.gz`
   Downloads NOAA HMS smoke polygons for the 765 high dates. Expected: 4,146 high
   site-days; plume density 0/1/2/3 = 1,487/361/582/1,716.
4. `python 03_episodes.py high_with_hms.csv.gz episodes.csv site_days_episode.csv.gz`
   Expected: 548 candidates, 59 eligible.
5. `python 04_families.py episodes.csv candidate_smoke_episodes_v2.csv family_sensitivity.csv`
   Expected: 29 families under the primary 800 km / 3 day rule.
6. `python 05_review_sheet.py candidate_smoke_episodes_v2.csv review_sheet.csv`

Shortcut: `high_with_hms.csv.gz` is included, so steps 4-6 run without any
downloads.

## Changes from v1

- Eligibility now requires strong plume evidence (at least half of site-days
  under a Medium or Heavy HMS plume) and 3+ sites. Light plumes never qualify
  a candidate on their own. Eligible candidates fell from 70 to 59.
- Winter (any day Nov-Feb) and fireworks (any day Jul 3-6 or Dec 30-Jan 2) are
  review flags, not automatic exclusions.
- The family step is now a script (04) with a sensitivity table, so `family_id`
  is reproducible.
- Added the human review sheet (05).

## Known limits

- HMS plumes can sit aloft, and the densest plume of the day may not cover a
  monitor for its whole 24-hour average. Plume overlap supports smoke; it does
  not prove ground exposure. Each final episode needs written corroboration.
- Several fires feeding one plume over the same region and days count as ONE
  exposure episode.
- QC choices (sample durations kept, exceptional-event rows, 75% completeness,
  median across instruments) need sensitivity checks before the protocol freeze.
