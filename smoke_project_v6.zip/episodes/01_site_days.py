"""Step 1: one PM2.5 value per monitoring site per day, 2021-2025, 15 states.

Input: EPA AirData daily_88101_<year>.csv files (unzipped), passed as arguments.
Output: site_days.csv.gz with site, state, lat, lon, date, pm25, n_instruments.

QC rules (frozen for the screening stage; each needs a sensitivity check later):
  - keep Sample Duration "24 HOUR" (filter samplers) and "24-HR BLK AVG"
    (daily averages of continuous monitors); drop "1 HOUR" rows, which repeat
    the same instrument-day as the block average
  - drop rows whose Event Type is "Excluded" (copies with exceptional-event
    data removed); keep "None" and "Included"
  - require Observation Percent >= 75
  - one value per site-day = median across instruments (POCs) at that site
"""
import sys
import pandas as pd

STATES = {
    "West": ["California", "Oregon", "Washington", "Idaho", "Montana", "Nevada",
             "Utah", "Arizona", "New Mexico", "Colorado"],
    "Southeast": ["North Carolina", "Virginia", "South Carolina", "Tennessee", "Georgia"],
}
state_region = {s: r for r, ss in STATES.items() for s in ss}
cols = ["State Code", "County Code", "Site Num", "POC", "Latitude", "Longitude",
        "Sample Duration", "Date Local", "Event Type", "Observation Percent",
        "Arithmetic Mean", "State Name", "Local Site Name"]

frames = []
for path in sys.argv[1:-1]:
    d = pd.read_csv(path, usecols=cols, low_memory=False)
    d = d[d["State Name"].isin(state_region)]
    d = d[d["Sample Duration"].isin(["24 HOUR", "24-HR BLK AVG"])]
    d = d[d["Event Type"].fillna("None") != "Excluded"]
    d = d[d["Observation Percent"] >= 75]
    d["site"] = (d["State Code"].astype(str).str.zfill(2) + "-" +
                 d["County Code"].astype(str).str.zfill(3) + "-" +
                 d["Site Num"].astype(str).str.zfill(4))
    g = d.groupby(["site", "Date Local"]).agg(
        pm25=("Arithmetic Mean", "median"),
        n_instruments=("POC", "nunique"),
        state=("State Name", "first"),
        site_name=("Local Site Name", "first"),
        lat=("Latitude", "first"),
        lon=("Longitude", "first"),
    ).reset_index().rename(columns={"Date Local": "date"})
    g["region"] = g["state"].map(state_region)
    frames.append(g)
    print(path, len(g), "site-days")

out = pd.concat(frames, ignore_index=True)
out.to_csv(sys.argv[-1], index=False, compression="gzip")
print("total", len(out), "site-days;", out.site.nunique(), "sites")
