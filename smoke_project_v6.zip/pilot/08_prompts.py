"""Step 8 (pilot): write the exact prompt for every target x condition.

Reads ONLY pilot_inputs.csv (no truth). Design: a 2 x 2 factorial plus a naive
reference. Every condition shares the same request and output format.

                              no environment          environment
                              (neighbor km + values)  (+ plume, weather, wind,
                                                       neighbor directions)
  identified (site, place,    arm_n                   arm_b
  date, neighbor names)
  anonymous (no place,        arm_n_masked            arm_b_masked
  region, month or date)

  arm_a  naive reference: identifiers only, no data at all.

arm_n_masked sees exactly what the IDW baseline sees (neighbor distances and
values, nothing else), so arm_n_masked vs IDW is the strictly fair test of AI
against arithmetic. The factorial also separates two effects:
  environment effect   (arm_b - arm_n) and (arm_b_masked - arm_n_masked)
  identifier effect    (arm_b - arm_b_masked) and (arm_n - arm_n_masked)
The identifier effect measures how much the model leans on knowing WHICH real
day and place it is (event knowledge from training data) rather than the data
in front of it.

Neighbor directions sit in the environment level because they only carry
information alongside wind direction.

Checks: no neighbor is the target or under 10 km away; the target's site ID
never appears; anonymous prompts contain no name, state, year, month or region.

Usage: python 08_prompts.py pilot_inputs.csv prompts.jsonl
"""
import calendar
import hashlib
import json
import sys

import pandas as pd

ASK = ('Generate one record for a dataset of daily air quality: the 24-hour average '
       'PM2.5 concentration, in micrograms per cubic meter, measured by the EPA monitor '
       '"{name}" in {state} (latitude {lat:.3f}, longitude {lon:.3f}) on {date}.')
ASK_ANON = ('Generate one record for a dataset of daily air quality: the 24-hour average '
            'PM2.5 concentration, in micrograms per cubic meter, measured by an EPA monitor '
            'on one day.')
FORMAT = ('Give a single realistic value. Respond with JSON only, exactly in this form: '
          '{"pm25_ug_m3": <number>}')
CONDITIONS = ["arm_a", "arm_n", "arm_n_masked", "arm_b", "arm_b_masked"]


def fmt(v, unit):
    return "missing" if v is None else f"{v:g} {unit}"


def weather_line(w, anon):
    if not w:
        return "- Weather: no station within 50 km reported enough hourly data that day"
    where = f"a weather station {w['station_km']:g} km away" if anon else \
        f"{w['station']} ({w['station_km']:g} km away)"
    wind_dir = w["wind_dir_vector_mean"] or "missing"
    return (f"- Weather at {where}, midnight to midnight local standard time: "
            f"mean temperature {fmt(w['temp_mean_f'], 'F')}, high {fmt(w['temp_max_f'], 'F')}, "
            f"low {fmt(w['temp_min_f'], 'F')}, dew point {fmt(w['dewpoint_f'], 'F')}, "
            f"mean wind {fmt(w['wind_mean_kt'], 'knots')} from the {wind_dir}, "
            f"max wind {fmt(w['wind_max_kt'], 'knots')}, precipitation {fmt(w['precip_in'], 'in')}")


def block(ctx, env, anon):
    lines = ["Information available for that day:"]
    if env:
        lines.append(f"- NOAA Hazard Mapping System smoke plume over this location: {ctx['hms_plume']}")
        lines.append(weather_line(ctx["weather"], anon))
    lines.append("- 24-hour average PM2.5 at other EPA monitors that day:")
    for i, n in enumerate(ctx["neighbors"], 1):
        label = f"Monitor {i}" if anon else f"{n['name']} ({n['state']})"
        where = f"{n['km']:g} km {n['direction']}" if env else f"{n['km']:g} km away"
        lines.append(f"  - {label}, {where}: {n['pm25']:g} ug/m3")
    return "\n".join(lines)


c = pd.read_csv(sys.argv[1])
out = []
for r in c.itertuples():
    name = str(r.site_name).strip()
    ctx = json.loads(r.context_json)
    assert all(n["site_id"] != r.site and n["km"] >= 10 for n in ctx["neighbors"]), r.target_id
    ask = ASK.format(name=name, state=r.state, lat=r.lat, lon=r.lon, date=r.date)
    prompts = {"arm_a": f"{ask}\n\n{FORMAT}",
               "arm_n": f"{ask}\n\n{block(ctx, env=False, anon=False)}\n\n{FORMAT}",
               "arm_n_masked": f"{ASK_ANON}\n\n{block(ctx, env=False, anon=True)}\n\n{FORMAT}",
               "arm_b": f"{ask}\n\n{block(ctx, env=True, anon=False)}\n\n{FORMAT}",
               "arm_b_masked": f"{ASK_ANON}\n\n{block(ctx, env=True, anon=True)}\n\n{FORMAT}"}
    month = calendar.month_name[int(r.date[5:7])]
    for arm in CONDITIONS:
        p = prompts[arm]
        assert r.site not in p, (r.target_id, arm)
        if arm.endswith("masked"):
            banned = [name, r.state, r.date[:4], month, "western", "southeastern"]
            banned += [n["name"] for n in ctx["neighbors"]]
            assert not any(b and b in p for b in banned), (r.target_id, arm)
        out.append({"target_id": r.target_id, "generation_condition": arm, "prompt": p,
                    "prompt_sha256": hashlib.sha256(p.encode()).hexdigest()})

with open(sys.argv[2], "w") as f:
    for o in out:
        f.write(json.dumps(o) + "\n")
print(len(out), "prompts written:", pd.Series([o["generation_condition"] for o in out]).value_counts().to_dict())
for k in (2, 4):
    print(f"\n--- example {out[k]['generation_condition']} ---\n" + out[k]["prompt"])
