"""Step 6 (pilot): draw 50 target site-days from 2020.

Why 2020: the confirmatory study uses 2021-2025 episodes. Drawing the pilot
from 2020 lets us test prompts, parsing and scoring without spending or peeking
at any confirmatory data. Pilot results never enter the final analysis.

Strata (seed fixed so the draw is reproducible):
  West high      20  (truth >= 35.5) on West high dates, Aug 15 - Oct 15 2020
  West low       20  (truth <  35.5) on those same dates, so the AI sees smoky
                     days where this particular site stayed below the line
  Southeast high  5  any 2020 Southeast day >= 35.5
  Southeast low   5  same dates as the Southeast high draws
At most 4 targets per date, and each target needs >= 3 neighbor monitors
10-150 km away reporting that day (the Arm B inputs and the baseline need them).

Usage: python 06_pilot_sample.py site_days_2020.csv.gz pilot_targets.csv
"""
import sys
import numpy as np
import pandas as pd

SEED, HIGH = 2026, 35.5
MIN_KM, MAX_KM, MIN_NEIGHBORS = 10, 150, 3

d = pd.read_csv(sys.argv[1])
d["date"] = pd.to_datetime(d.date)
rng = np.random.default_rng(SEED)


def km(lat1, lon1, lat2, lon2):
    p = np.pi / 180
    a = (np.sin((lat2 - lat1) * p / 2) ** 2 +
         np.cos(lat1 * p) * np.cos(lat2 * p) * np.sin((lon2 - lon1) * p / 2) ** 2)
    return 12742 * np.arcsin(np.sqrt(a))


def n_neighbors(row, day):
    dist = km(row.lat, row.lon, day.lat.values, day.lon.values)
    return int(((dist >= MIN_KM) & (dist <= MAX_KM)).sum())


by_date = {k: g for k, g in d.groupby("date")}


def eligible(rows):
    keep = [n_neighbors(r, by_date[r.date]) >= MIN_NEIGHBORS for r in rows.itertuples()]
    return rows[keep]


def draw(pool, n, label, used_dates):
    pool = eligible(pool).sample(frac=1, random_state=int(rng.integers(1e9)))
    out, per_date = [], {}
    for r in pool.itertuples():
        if per_date.get(r.date, 0) >= 4:
            continue
        out.append(r.Index)
        per_date[r.date] = per_date.get(r.date, 0) + 1
        if len(out) == n:
            break
    if len(out) < n:
        raise SystemExit(f"{label}: only {len(out)} eligible targets")
    s = d.loc[out].copy()
    s["stratum"] = label
    used_dates.update(s.date)
    return s


w = d[(d.region == "West") & d.date.between("2020-08-15", "2020-10-15")]
w_dates = w[w.pm25 >= HIGH].date.unique()
w = w[w.date.isin(w_dates)]
se = d[d.region == "Southeast"]
se_dates = se[se.pm25 >= HIGH].date.unique()

used = set()
parts = [draw(w[w.pm25 >= HIGH], 20, "west_high", used),
         draw(w[w.pm25 < HIGH], 20, "west_low", used),
         draw(se[se.pm25 >= HIGH], 5, "se_high", used)]
se_hi_dates = parts[-1].date.unique()
parts.append(draw(se[se.date.isin(se_hi_dates) & (se.pm25 < HIGH)], 5, "se_low", used))

t = pd.concat(parts)
t["target_id"] = [f"P{i:03d}" for i in range(1, len(t) + 1)]
# cluster = region x date: targets on the same regional day share one smoke situation
t["cluster"] = t.region + "_" + t.date.dt.strftime("%Y-%m-%d")
t["date"] = t.date.dt.strftime("%Y-%m-%d")
cols = ["target_id", "stratum", "cluster", "site", "site_name", "state", "region",
        "lat", "lon", "date", "pm25"]
t[cols].rename(columns={"pm25": "truth_pm25"}).to_csv(sys.argv[2], index=False)
print(t.groupby("stratum").agg(n=("site", "size"), sites=("site", "nunique"),
                               dates=("date", "nunique"), median_pm25=("pm25", "median")))
print("clusters:", t.cluster.nunique())
