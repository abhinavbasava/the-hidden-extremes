"""Step 7 (pilot): build the model inputs, the neighbor baseline, a separate scoring
key and a frozen evaluation manifest.

Design: leave-one-site-out. Each target is reconstructed as if ITS monitor alone
were missing that day; every other monitor keeps its real reading. Two targets
can therefore appear in each other's neighbor lists (e.g. P042 and P046), which
is correct for this design. All rules live in context_lib.py, shared with the
conventional comparator (12_contextual_comparator.py).

Outputs (the split keeps answers out of the generation workspace):
  pilot_inputs.csv          everything the prompts may use. NO truth, NO stratum.
  scoring_key.csv           truth, stratum, cluster, IDW. Only the scorer reads it.
  evaluation_manifest.json  SHA-256 of the scoring key and inputs, written now,
                            BEFORE any generation; the scorer refuses a key that
                            no longer matches it.
  sources_manifest.csv      URL and SHA-256 of every source file used.

Usage: python 07_context.py pilot_targets.csv site_days_2020.csv.gz isd-history.csv cache_dir outdir [raw EPA files to hash ...]
"""
import datetime as dt
import json
import os
import sys

import numpy as np
import pandas as pd

from context_lib import NAMES, Context, MIN_KM, neighbors, sha

targets_path, sd_path, isd_path, cache, outdir = sys.argv[1:6]
raw_epa = sys.argv[6:]
os.makedirs(outdir, exist_ok=True)
C = Context(isd_path, cache)
C.log(sd_path, "built by 01_site_days.py from https://aqs.epa.gov/aqsweb/airdata/daily_88101_2020.zip")
for f in raw_epa:
    name = os.path.basename(f)
    C.log(f, f"https://aqs.epa.gov/aqsweb/airdata/{name}" if name.endswith(".zip")
          else f"extracted from {name.rsplit('.', 1)[0]}.zip")

t = pd.read_csv(targets_path)
sd = pd.read_csv(sd_path)
sd = sd[sd.date.isin(t.date.unique())]
by_date = {k: g for k, g in sd.groupby("date")}
inputs, key = [], []
for r in t.itertuples():
    nbs, idw = neighbors(by_date[r.date], r.site, r.lat, r.lon)
    assert nbs and all(n["km"] >= MIN_KM for n in nbs) and r.site not in {n["site_id"] for n in nbs}
    dens = C.plume(r.date, r.lat, r.lon)
    wx = C.weather(r.date, r.lat, r.lon)
    ctx = {"neighbors": nbs, "hms_plume": NAMES[dens] if dens is not None else "unavailable", "weather": wx}
    inputs.append({"target_id": r.target_id, "site": r.site, "site_name": r.site_name, "state": r.state,
                   "region": r.region, "lat": r.lat, "lon": r.lon, "date": r.date,
                   "context_json": json.dumps(ctx)})
    key.append({"target_id": r.target_id, "stratum": r.stratum, "cluster": r.cluster,
                "truth_pm25": r.truth_pm25, "baseline_idw": round(idw, 3),
                "n_neighbors": len(nbs), "nearest_neighbor_km": float(min(n["km"] for n in nbs)),
                "hms_plume": ctx["hms_plume"], "weather_missing": wx is None})

ip, kp = os.path.join(outdir, "pilot_inputs.csv"), os.path.join(outdir, "scoring_key.csv")
pd.DataFrame(inputs).to_csv(ip, index=False)
k = pd.DataFrame(key)
k.to_csv(kp, index=False)
json.dump({"scoring_key_sha256": sha(kp), "inputs_sha256": sha(ip), "n_targets": len(k),
           "frozen_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
           "note": "Written before any AI generation. The scorer refuses a scoring key that differs."},
          open(os.path.join(outdir, "evaluation_manifest.json"), "w"), indent=2)
C.manifest().to_csv(os.path.join(outdir, "sources_manifest.csv"), index=False)
print(len(k), "targets |", "plume:", k.hms_plume.value_counts().to_dict(),
      "| weather missing:", int(k.weather_missing.sum()), "| neighbors:", k.n_neighbors.value_counts().to_dict())
print(len(C.sources), "source files hashed")
