"""Step 10: validate the run, then score every AI condition and both conventional methods.

Threshold: 35.5 ug/m3, where the 24-hour PM2.5 AQI enters "Unhealthy for
Sensitive Groups" (USG). Days at or above it are USG+ days. They are NOT
"Hazardous", a separate AQI category starting at 225.5. Secondary: 55.5.

PRIMARY OUTCOME (practical): arm_b minus IDW in miss rate on smoke-supported
USG+ days (truth >= 35.5 under a Medium/Heavy HMS plume). Directional
hypothesis (AI misses MORE), two-sided intervals. Verdict rules, fixed now:
  difference   95% interval excludes 0            -> "AI misses more" / "AI misses fewer"
  equivalence  90% interval inside +/- 10 points  -> "equivalent within 10 points"
  otherwise                                        -> "inconclusive"
A non-significant difference is never reported as "AI matches IDW".

Other contrasts: FAIR arm_n_masked - idw (identical information); arm_b -
ctx_reg (AI vs a conventional model with similar information); environment
effect; identifier effect; INTERACTION (arm_b - arm_n) - (arm_b_masked -
arm_n_masked), i.e. does context help differently when the model knows the
real place and date. Neither the identifier effect nor the interaction proves
memorization; they show reliance on identity, whatever the mechanism.

Weighting: default --weighting cluster gives every cluster (region x date in
the pilot; a smoke episode in the confirmatory study) equal weight, so one big
smoky day cannot dominate. --weighting pooled weights site-days equally.

Validation (refuses to score if any check fails):
  - evaluation manifest: scoring key unchanged since it was frozen
  - run manifest present; repeats from the manifest; exact key set
  - one provider / requested model / temperature / returned model
  - prompt hashes match; every value re-parses from the raw response
  - no mock rows unless --allow-mock

Per target x condition: AVAILABLE only if >= 2 of the repeats parse; value =
MEDIAN of valid repeats. Unavailable on a USG+ day counts as a miss; on a
below-line day it is reported, never counted as correct.

Also reported: compression slope (OLS slope of log estimate on log truth; < 1
means extremes get squeezed toward ordinary values) and a failure analysis by
severity, neighbor distance, neighbor disagreement and region
(<out>_failures.csv).

Usage: python 10_score.py scoring_key.csv generations.csv prompts.jsonl scores.csv
           [--inputs pilot_inputs.csv] [--comparator comparator_predictions.csv]
           [--weighting cluster|pooled] [--allow-mock]
"""
import argparse
import hashlib
import json
import math
import os
import re
import sys

import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("key")
ap.add_argument("generations")
ap.add_argument("prompts")
ap.add_argument("out")
ap.add_argument("--inputs", default="pilot_inputs.csv")
ap.add_argument("--comparator", default=None)
ap.add_argument("--eval-manifest", default="evaluation_manifest.json")
ap.add_argument("--weighting", choices=["cluster", "pooled"], default="cluster")
ap.add_argument("--allow-mock", action="store_true")
a = ap.parse_args()
USG, UNH, B, MARGIN = 35.5, 55.5, 2000, 0.10


def sha(p):
    return hashlib.sha256(open(p, "rb").read()).hexdigest()


def reparse(text):
    try:
        v = float(json.loads(re.search(r"\{.*\}", str(text), re.S).group(0))["pm25_ug_m3"])
        return v if math.isfinite(v) and v >= 0 else None
    except Exception:
        return None


# ---------- validation ----------
problems = []
if not os.path.exists(a.eval_manifest):
    sys.exit(f"REFUSED: no evaluation manifest at {a.eval_manifest}")
em = json.load(open(a.eval_manifest))
if em["scoring_key_sha256"] != sha(a.key):
    problems.append("scoring key changed since the evaluation manifest froze it")
key = pd.read_csv(a.key)
gen = pd.read_csv(a.generations)
prm = pd.DataFrame([json.loads(x) for x in open(a.prompts)])
mpath = a.generations + ".manifest.json"
if not os.path.exists(mpath):
    sys.exit(f"REFUSED: no run manifest at {mpath}")
man = json.load(open(mpath))
cols = ["target_id", "generation_condition", "repeat"]
expected = {(t, c, r) for t, c in zip(prm.target_id, prm.generation_condition)
            for r in range(1, man["repeats"] + 1)}
got = list(gen[cols].itertuples(index=False, name=None))
if len(got) != len(set(got)):
    problems.append("duplicate target x condition x repeat rows")
if set(got) != expected:
    problems.append(f"key set mismatch: {len(expected - set(got))} missing, {len(set(got) - expected)} unexpected")
if set(key.target_id) != set(prm.target_id):
    problems.append("scoring key targets differ from prompt targets")
for col, mk in [("provider", "provider"), ("requested_model", "model"), ("temperature", "temperature")]:
    if gen[col].nunique() != 1 or gen[col].iloc[0] != man[mk]:
        problems.append(f"{col} differs from the manifest or varies across rows")
if gen.returned_model.nunique() != 1:
    problems.append(f"more than one returned model: {gen.returned_model.unique().tolist()}")
h = gen.merge(prm[["target_id", "generation_condition", "prompt_sha256"]],
              on=["target_id", "generation_condition"], how="left", suffixes=("", "_expected"))
if (h.prompt_sha256 != h.prompt_sha256_expected).any():
    problems.append("prompt hashes do not match prompts.jsonl")
rp = gen.raw_response.map(reparse)
bad = (rp.notna() != gen.parse_ok) | (gen.parse_ok & ~np.isclose(rp.fillna(-1), gen.ai_pm25_ug_m3.fillna(-1)))
if bad.any():
    problems.append(f"{int(bad.sum())} rows where the stored value disagrees with the raw response")
if gen.is_mock.any() and not a.allow_mock:
    problems.append("mock rows present (use --allow-mock only to test code)")
if problems:
    sys.exit("REFUSED:\n  " + "\n  ".join(problems))
if gen.is_mock.any():
    print("WARNING: MOCK RUN. These numbers test the code, not any AI model.\n")
gen["ai_pm25_ug_m3"] = rp


# ---------- assemble one value per target x method ----------
def collapse(g):
    v = g.ai_pm25_ug_m3.dropna()
    return v.median() if len(v) >= 2 else np.nan


est = gen.groupby(["target_id", "generation_condition"]).apply(collapse, include_groups=False).unstack()
spread = gen.dropna(subset=["ai_pm25_ug_m3"]).groupby(["generation_condition", "target_id"]).ai_pm25_ug_m3.std()
df = key.set_index("target_id").join(est).rename(columns={"baseline_idw": "idw"})
if a.comparator:
    df = df.join(pd.read_csv(a.comparator).set_index("target_id")[["ctx_reg"]])
inp = pd.read_csv(a.inputs).set_index("target_id")
nb_vals = inp.context_json.map(lambda s: [n["pm25"] for n in json.loads(s)["neighbors"]])
df["neighbor_cv"] = nb_vals.map(lambda v: float(np.std(v) / np.mean(v)) if np.mean(v) > 0 else 0.0)
df["region"] = inp.region
df = df.reset_index()
df["smoke"] = df.hms_plume.isin(["Medium", "Heavy"])
order = ["arm_a", "arm_n", "arm_n_masked", "arm_b", "arm_b_masked", "ctx_reg", "idw"]
conds = [c for c in order if c in df]


def wrate(d, mask, x):
    """Rate of x among rows in mask; cluster weighting averages per-cluster rates."""
    if not mask.any():
        return np.nan
    if a.weighting == "pooled":
        return float(x[mask].mean())
    return float(x[mask].groupby(d.cluster[mask]).mean().mean())


def metrics(d, c):
    v, t = d[c], d.truth_pm25
    usg, low, unh = t >= USG, t < USG, t >= UNH
    flag, avail = (v >= USG).astype(float), v.notna()
    ok = avail & (t > 0)
    lv, lt = np.log1p(v[ok]), np.log1p(t[ok])
    slope = float(np.polyfit(lt, lv, 1)[0]) if ok.sum() >= 5 and lt.std() > 0 else np.nan
    return {"coverage": float(avail.mean()),
            "miss_usg": 1 - wrate(d, usg, flag),
            "miss_usg_smoke": 1 - wrate(d, usg & d.smoke, flag),
            "miss_usg_available": 1 - wrate(d, usg & avail, flag),
            "false_alarm": wrate(d, low & avail, flag),
            "unavailable_on_low_days": int((low & ~avail).sum()),
            "miss_unhealthy": 1 - wrate(d, unh, (v >= UNH).astype(float)),
            "median_ratio_usg": float((v / t)[usg & avail].median()) if (usg & avail).any() else np.nan,
            "compression_slope": slope,
            "mae": wrate(d, avail, (v - t).abs())}


CONTRASTS = {
    "PRIMARY arm_b - idw": [(1, "arm_b"), (-1, "idw")],
    "FAIR arm_n_masked - idw": [(1, "arm_n_masked"), (-1, "idw")],
    "arm_b - ctx_reg": [(1, "arm_b"), (-1, "ctx_reg")],
    "ctx_reg - idw": [(1, "ctx_reg"), (-1, "idw")],
    "arm_a - idw": [(1, "arm_a"), (-1, "idw")],
    "environment effect": [(.5, "arm_b"), (-.5, "arm_n"), (.5, "arm_b_masked"), (-.5, "arm_n_masked")],
    "identifier effect": [(.5, "arm_b"), (-.5, "arm_b_masked"), (.5, "arm_n"), (-.5, "arm_n_masked")],
    "INTERACTION": [(1, "arm_b"), (-1, "arm_n"), (-1, "arm_b_masked"), (1, "arm_n_masked")],
}
CONTRASTS = {k: v for k, v in CONTRASTS.items() if all(c in conds for _, c in v)}
DIFF_METRICS = ["miss_usg_smoke", "miss_usg", "false_alarm", "mae", "compression_slope"]


def contrast(ms, terms, k):
    return sum(w * ms[c][k] for w, c in terms)


rng = np.random.default_rng(2026)
groups = {k: g for k, g in df.groupby("cluster")}
clusters = list(groups)
boot = []
for _ in range(B):
    s = pd.concat([groups[k] for k in rng.choice(clusters, len(clusters))], ignore_index=True)
    ms = {c: metrics(s, c) for c in conds}
    row = {(c, k): v for c in conds for k, v in ms[c].items()}
    for name, terms in CONTRASTS.items():
        for k in DIFF_METRICS:
            row[(name, k)] = contrast(ms, terms, k)
    boot.append(row)
boot = pd.DataFrame(boot)

point = {c: metrics(df, c) for c in conds}
rows = []
for c in conds:
    for k, v in point[c].items():
        lo, hi = (np.nan, np.nan) if k == "unavailable_on_low_days" else np.nanpercentile(boot[(c, k)], [2.5, 97.5])
        rows.append({"comparison": c, "metric": k, "estimate": v, "ci95_low": lo, "ci95_high": hi})
verdict = None
for name, terms in CONTRASTS.items():
    for k in DIFF_METRICS:
        b = boot[(name, k)]
        lo, hi = np.nanpercentile(b, [2.5, 97.5])
        lo90, hi90 = np.nanpercentile(b, [5, 95])
        est_ = contrast(point, terms, k)
        rows.append({"comparison": name, "metric": k, "estimate": est_, "ci95_low": lo, "ci95_high": hi,
                     "ci90_low": lo90, "ci90_high": hi90})
        if name.startswith("PRIMARY") and k == "miss_usg_smoke":
            if lo > 0:
                verdict = "AI misses MORE smoke-supported USG+ days than IDW"
            elif hi < 0:
                verdict = "AI misses FEWER smoke-supported USG+ days than IDW"
            elif -MARGIN < lo90 and hi90 < MARGIN:
                verdict = f"equivalent within +/-{int(MARGIN * 100)} points (90% interval)"
            else:
                verdict = "inconclusive (interval too wide to call a difference or equivalence)"
out = pd.DataFrame(rows).round(3)
out.to_csv(a.out, index=False)

# ---------- failure analysis ----------
fa = []
bins = {
    "severity": pd.cut(df.truth_pm25, [USG, 55.5, 125.5, np.inf], right=False,
                       labels=["USG 35.5-55.4", "Unhealthy 55.5-125.4", "Very unhealthy+ 125.5+"]),
    "nearest neighbor": pd.cut(df.nearest_neighbor_km, [0, 30, 60, np.inf], labels=["<30 km", "30-60 km", ">60 km"]),
    "neighbor disagreement": pd.qcut(df.neighbor_cv, 2, labels=["low CV", "high CV"]),
    "region": df.region,
}
usg = df.truth_pm25 >= USG
for factor, b in bins.items():
    for level in b.dropna().unique():
        m = usg & (b == level)
        if not m.any():
            continue
        for c in conds:
            v, t = df.loc[m, c], df.loc[m, "truth_pm25"]
            fa.append({"factor": factor, "level": str(level), "method": c, "n_usg_days": int(m.sum()),
                       "miss_rate": float((v.fillna(-1) < USG).mean()), "median_ratio": float((v / t).median())})
pd.DataFrame(fa).round(3).to_csv(a.out.replace(".csv", "_failures.csv"), index=False)

n_usg = int(usg.sum())
print(f"weighting: {a.weighting} | {n_usg} USG+ / {len(df) - n_usg} below-line site-days, {len(clusters)} clusters, "
      f"{int((usg & df.smoke).sum())} smoke-supported USG+\n")
print(out[out.comparison.isin(conds)].pivot(index="metric", columns="comparison", values="estimate")[conds].to_string())
print("\nContrasts (negative miss = fewer misses than the comparison):")
d = out[~out.comparison.isin(conds) & out.metric.isin(["miss_usg_smoke", "false_alarm", "compression_slope"])]
print(d.assign(ci95=d.apply(lambda r: f"[{r.ci95_low}, {r.ci95_high}]", axis=1))[
    ["comparison", "metric", "estimate", "ci95"]].to_string(index=False))
print(f"\nPRIMARY VERDICT: {verdict}")
print("\nRun-to-run SD of AI values (median across targets):")
print(spread.groupby(level=0).median().round(2).to_string())
