"""Step 12: the contextual conventional comparator (a non-AI method with the same
environmental information as arm_b).

Pre-specified BEFORE any AI result exists. Nothing here may change after the
team sees AI output.

Training data: pre-2021 only. For the 2020 pilot it trains on 2018-2019; for the
2021-2025 confirmatory study it retrains on 2018-2020 (pass the years).
Training rows use the SAME leave-one-site-out neighbor, plume and weather code
as the AI inputs (context_lib.py). Target-site readings never enter predictors.

Training sample (fixed, seed 2026): every USG+ site-day (>= 35.5) in the
training years, plus a random sample of below-line site-days, 4,000 per run.
Rows need >= 3 neighbors, the same rule as the pilot targets.

Model: ordinary least squares on y = log(PM2.5 + 1), predictors:
  log(IDW + 1), log(max neighbor + 1), log(nearest neighbor km),
  plume Light / Medium / Heavy (none = reference),
  mean temperature F, dew point F, mean wind knots, precipitation in,
  precipitation-missing flag, weather-missing flag,
  sin and cos of month, West-region flag.
Missing weather: weather variables set to training means plus the flag.
Missing precipitation: set to 0 plus its flag.
Negative readings: EPA reports small negative daily PM2.5 values near the
detection limit. Inside this regression only, values are floored at 0 before
the log transform (targets and neighbor features). AI prompts keep the
readings exactly as measured.
Back-transform: Duan smearing, prediction = exp(Xb) * mean(exp(residual)) - 1,
floored at 0. Wind direction is not used (it needs upwind geometry that a
linear model cannot use without extra, unvalidated features).

Validation (pre-2021 only): leave-one-year-out. Fit on one year, predict the
other, and compare with IDW on the same rows (MAE, USG+ miss rate, false
alarms, smoke-supported miss rate).

Outputs (in outdir):
  comparator_training.csv       the training rows and features
  comparator_validation.csv     leave-one-year-out results vs IDW
  comparator_model.json         coefficients, smearing factor, means, spec
  comparator_predictions.csv    predictions for the targets (no truth used)

Usage: python 12_contextual_comparator.py site_days_train.csv.gz isd-history.csv cache_dir \
           pilot_inputs.csv outdir --train-years 2018 2019
"""
import argparse
import json
import os

import numpy as np
import pandas as pd

from context_lib import Context, NAMES, neighbors

ap = argparse.ArgumentParser()
ap.add_argument("site_days")
ap.add_argument("isd")
ap.add_argument("cache")
ap.add_argument("targets_inputs")
ap.add_argument("outdir")
ap.add_argument("--train-years", nargs="+", required=True)
ap.add_argument("--n-low", type=int, default=4000)
a = ap.parse_args()
os.makedirs(a.outdir, exist_ok=True)
assert all(int(y) <= 2020 for y in a.train_years), "training must be pre-2021"
USG, SEED = 35.5, 2026
DENS = {v: k for k, v in NAMES.items()}
FEATURES = ["log_idw", "log_max_nb", "log_near_km", "plume_light", "plume_medium", "plume_heavy",
            "temp_mean_f", "dewpoint_f", "wind_mean_kt", "precip_in", "precip_missing", "weather_missing",
            "month_sin", "month_cos", "west"]
WX = ["temp_mean_f", "dewpoint_f", "wind_mean_kt"]


def raw_features(nbs, idw, dens, wx, date, region):
    m = int(date[5:7])
    f = {"log_idw": np.log1p(max(idw, 0)), "log_max_nb": np.log1p(max(max(n["pm25"] for n in nbs), 0)),
         "log_near_km": np.log(min(n["km"] for n in nbs)),
         "plume_light": int(dens == 1), "plume_medium": int(dens == 2), "plume_heavy": int(dens == 3),
         "weather_missing": int(wx is None), "month_sin": np.sin(2 * np.pi * m / 12),
         "month_cos": np.cos(2 * np.pi * m / 12), "west": int(region == "West")}
    for k in WX:
        f[k] = (wx or {}).get(k)
    p = (wx or {}).get("precip_in")
    f["precip_in"], f["precip_missing"] = (0.0, 1) if p is None else (p, 0)
    return f


def design(df, means):
    X = df[FEATURES].copy()
    for k in WX:
        X[k] = X[k].fillna(means[k])
    return np.column_stack([np.ones(len(X)), X.values.astype(float)])


def fit(df):
    means = {k: float(df[k].mean()) for k in WX}
    X, y = design(df, means), np.log1p(np.clip(df.truth.values, 0, None))
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    smear = float(np.mean(np.exp(y - X @ beta)))
    return {"beta": beta.tolist(), "smear": smear, "means": means}


def predict(model, df):
    X = design(df, model["means"])
    return np.maximum(np.exp(X @ np.array(model["beta"])) * model["smear"] - 1, 0)


# ---------- training set ----------
C = Context(a.isd, a.cache)
sd = pd.read_csv(a.site_days)
sd = sd[sd.date.str[:4].isin(a.train_years)]
rng = np.random.default_rng(SEED)
hi = sd[sd.pm25 >= USG]
lo = sd[sd.pm25 < USG].sample(n=min(a.n_low, int((sd.pm25 < USG).sum())), random_state=SEED)
sample = pd.concat([hi, lo]).sort_values("date")
by_date = {k: g for k, g in sd[sd.date.isin(sample.date.unique())].groupby("date")}
rows = []
for i, r in enumerate(sample.itertuples()):
    nbs, idw = neighbors(by_date[r.date], r.site, r.lat, r.lon)
    if len(nbs) < 3:
        continue
    dens = C.plume(r.date, r.lat, r.lon)
    wx = C.weather(r.date, r.lat, r.lon)
    rows.append({"site": r.site, "date": r.date, "region": r.region, "truth": r.pm25, "idw": idw,
                 "dens": dens, **raw_features(nbs, idw, dens if dens is not None else 0, wx, r.date, r.region)})
    if i % 500 == 0:
        print(f"{i}/{len(sample)} training rows built", flush=True)
tr = pd.DataFrame(rows)
tr["year"] = tr.date.str[:4]
tr.to_csv(os.path.join(a.outdir, "comparator_training.csv"), index=False)
print(f"training rows: {len(tr)} ({int((tr.truth >= USG).sum())} USG+) | weather missing: "
      f"{int(tr.weather_missing.sum())} | precip missing: {int(tr.precip_missing.sum())}")


# ---------- leave-one-year-out validation ----------
def scores(d, pred):
    usg, low, smoke = d.truth >= USG, d.truth < USG, (d.truth >= USG) & (d.dens >= 2)
    return {"n": len(d), "n_usg": int(usg.sum()), "mae": float(np.mean(np.abs(pred - d.truth))),
            "miss_usg": float(np.mean(pred[usg] < USG)) if usg.any() else np.nan,
            "miss_usg_smoke": float(np.mean(pred[smoke] < USG)) if smoke.any() else np.nan,
            "false_alarm": float(np.mean(pred[low] >= USG)) if low.any() else np.nan}


val = []
if len(a.train_years) > 1:
    for test_year in a.train_years:
        train, test = tr[tr.year != test_year], tr[tr.year == test_year]
        m = fit(train)
        val.append({"test_year": test_year, "method": "ctx_reg", **scores(test, predict(m, test))})
        val.append({"test_year": test_year, "method": "idw", **scores(test, test.idw.values)})
val = pd.DataFrame(val)
val.to_csv(os.path.join(a.outdir, "comparator_validation.csv"), index=False)
if len(val):
    print("\nLeave-one-year-out validation (pre-2021 only):")
    print(val.round(3).to_string(index=False))

# ---------- final model and target predictions ----------
model = fit(tr)
json.dump({**model, "features": ["intercept"] + FEATURES, "train_years": a.train_years,
           "n_train": len(tr), "target": "log(PM2.5 + 1)", "back_transform": "Duan smearing",
           "seed": SEED, "n_low_sampled": a.n_low},
          open(os.path.join(a.outdir, "comparator_model.json"), "w"), indent=2)
inp = pd.read_csv(a.targets_inputs)
feats = []
for r in inp.itertuples():
    ctx = json.loads(r.context_json)
    nbs = ctx["neighbors"]
    dk = np.array([n["km"] for n in nbs])
    v = np.array([n["pm25"] for n in nbs])
    idw = float(np.sum(v / dk ** 2) / np.sum(1 / dk ** 2))
    dens = DENS.get(ctx["hms_plume"], 0)
    feats.append({"target_id": r.target_id, **raw_features(nbs, idw, dens, ctx["weather"], r.date, r.region)})
fdf = pd.DataFrame(feats)
fdf["ctx_reg"] = predict(model, fdf).round(3)
fdf[["target_id", "ctx_reg"]].to_csv(os.path.join(a.outdir, "comparator_predictions.csv"), index=False)
print(f"\nPredictions written for {len(fdf)} targets (truth not used).")
print("Coefficients:", {k: round(b, 3) for k, b in zip(["intercept"] + FEATURES, model["beta"])})
