# Pilot, v6 (Nov 25, 2026)

Engineering pilot on 50 site-days from **2020**, kept out of the 2021-2025
confirmatory data. Pilot numbers never enter the final analysis, and nobody
changes the hypothesis because of them. A null pilot is fine; its job is to
find code and prompt problems.

Terminology: 35.5 ug/m3 is where the 24-hour PM2.5 AQI enters "Unhealthy for
Sensitive Groups." Days at or above it are **USG+ days**. "Hazardous" is a
different AQI category (225.5 and up); never use it for this threshold.

## Run it

```
python 01_site_days.py daily_88101_2020.csv site_days_2020.csv.gz      # 102,534 site-days, 356 sites
python 06_pilot_sample.py site_days_2020.csv.gz pilot_targets.csv       # 50 targets, 28 clusters
python 07_context.py pilot_targets.csv site_days_2020.csv.gz isd-history.csv cache/ . \
       daily_88101_2020.zip daily_88101_2020.csv      # inputs, scoring key, FROZEN evaluation manifest
python 08_prompts.py pilot_inputs.csv prompts.jsonl                     # 250 prompts, 5 conditions
python 01_site_days.py daily_88101_2018.csv daily_88101_2019.csv site_days_2018_2019.csv.gz
python 12_contextual_comparator.py site_days_2018_2019.csv.gz isd-history.csv cache/ \
       pilot_inputs.csv . --train-years 2018 2019                       # conventional comparator
python validate_v5.py .                                                 # preflight
python 11_selftest.py                                                   # 13/13 must pass
python 09_generate.py prompts.jsonl pilot_inputs.csv generations.csv \
       --provider anthropic --model <exact model id> --repeats 3        # 750 AI records, random order
python validate_v5.py . --run generations.csv                           # postflight
python 10_score.py scoring_key.csv generations.csv prompts.jsonl scores.csv \
       --comparator comparator_predictions.csv                          # + scores_failures.csv
```

`00_download_sources.py sources_manifest.csv downloads/` re-downloads every
source file and checks its SHA-256. Keep API keys in environment variables
(`ANTHROPIC_API_KEY` or `OPENAI_API_KEY`), never in a file, the ZIP or a chat.
Cost: 750 short requests, roughly $1-2 on a current mid-tier model.

## Design: 2 x 2 factorial, a naive reference, two conventional methods

|  | Neighbors only (km + values) | + Environment (plume, weather, wind, neighbor directions) |
|---|---|---|
| **Identified** (site, place, date, neighbor names) | arm_n | arm_b |
| **Anonymous** (no place, region, month or date) | arm_n_masked | arm_b_masked |

- arm_a: identifiers only, no data ("just ask the AI").
- idw: inverse-distance weighting of the same neighbors.
- ctx_reg: log-scale regression on IDW, max neighbor, plume, weather, month and
  region, trained only on pre-2021 data with the same leave-one-site-out code
  (`context_lib.py`), validated leave-one-year-out.

**Primary (practical):** arm_b vs IDW, miss rate on smoke-supported USG+ days.
Directional hypothesis (AI misses more), two-sided intervals. Verdicts fixed in
advance: 95% interval excludes 0 = a difference; 90% interval inside +/-10
points = equivalent; otherwise inconclusive. Never "AI matches IDW" from a
non-significant result.

**Secondary:** arm_n_masked vs IDW (identical information); arm_b vs ctx_reg
(similar information); environment effect; identifier effect; interaction
(does context help differently when the model knows the real place and date).
The identifier effect and interaction show reliance on identity; they do not
prove memorization.

**Weighting:** every cluster counts equally (region x date here; one smoke
episode in the confirmatory study). `--weighting pooled` gives the site-day view.

**Also scored:** compression slope (do extremes get squeezed toward ordinary
values?) and a failure analysis by severity, neighbor distance, neighbor
disagreement and region.

## Safeguards

- Leave-one-site-out neighbors, 10-150 km, stored with site IDs; one shared
  implementation for the AI inputs and the comparator.
- Answers live only in `scoring_key.csv`, frozen by `evaluation_manifest.json`
  before any generation; the scorer refuses an edited key.
- Weather: NOAA ISD-Lite hourly data over EPA's local-standard-time day.
- Generator: run manifest (prompts, inputs, script hashes, settings, order
  seed); randomized request order with `request_index` logged; full API
  provenance per record; mismatched resumes refused.
- Scorer: exact key set, manifest repeats, one returned model, raw re-parse,
  2-of-3 availability, failures never counted as correct.
- `validate_v5.py` (ChatGPT audit, updated) checks independently;
  `11_selftest.py` proves seven kinds of corruption get caught.

## Go / no-go (written before running)

1. Self-test 13/13, preflight and postflight pass.
2. Under 5% of records fail to parse in every condition.
3. One returned model for the whole run.
4. The run completes without manual fixes.
5. Both partners read 10 random prompts per condition and agree they are clear.

## Decisions to lock as a team by Dec 15

1. Primary outcome and verdict rules above (equivalence margin 10 points).
2. **Region:** Liu et al. (2024, IJWF) found that outside the West, surface
   smoke under HMS plumes is low and barely differs by plume density. Proposed:
   West = primary analysis; Southeast = pre-specified robustness analysis and a
   featured North Carolina case study, corroborated with NC DEQ
   exceptional-event records. Decide before any confirmatory AI output exists.
3. Which conditions go into the confirmatory run (cost is trivial; the limit
   is how much the poster can explain).
4. Retrain ctx_reg on 2018-2020 for the confirmatory study; freeze it before
   generation.
5. Missing data: 3 targets lack weather and 15 more lack precipitation (18 of
   50 without precipitation); 1 precipitation value uses an approximate
   6-hour window. Keep them with "missing" in the prompt and run a
   complete-weather sensitivity check.

## Known pilot facts

- Every 2020 Southeast USG+ day fell on July 5 or June 27: potential
  non-wildfire controls (fireworks; Saharan dust). Plume absence alone does not
  prove the source.
- IDW on the real pilot data: 21 of 25 USG+ days flagged, 18 of 20
  smoke-supported (13 clusters), 0 false alarms, MAE 9.04 ug/m3.

## Changes from v5

Contextual comparator (`12_contextual_comparator.py`) on a shared context
library (refactor verified byte-identical); interaction contrast;
pre-specified verdict rules with an equivalence margin; equal-cluster
weighting; compression slope; failure analysis; frozen evaluation manifest;
randomized request order; source re-download script; raw EPA URL in the
manifest; seventh self-test.
