"""Step 0: re-download every downloadable source file listed in sources_manifest.csv
and check its SHA-256, so anyone can confirm they hold the exact files we used.

Rows whose URL is a description ("built by ...", "extracted from ...") are
rebuilt by the pipeline scripts instead. A hash mismatch usually means the
agency regenerated the file since our download (EPA AirData files are refreshed
periodically); the script reports it, it never hides it.

Usage: python 00_download_sources.py sources_manifest.csv download_dir
"""
import hashlib
import os
import sys
import urllib.request

import pandas as pd

m = pd.read_csv(sys.argv[1])
out = sys.argv[2]
os.makedirs(out, exist_ok=True)
ok = bad = skipped = 0
for r in m.itertuples():
    if not str(r.url).startswith("http") or r.url.endswith(".html"):
        skipped += 1
        continue
    path = os.path.join(out, r.file)
    if not os.path.exists(path):
        try:
            urllib.request.urlretrieve(r.url, path)
        except Exception as e:
            print(f"FAILED  {r.file}: {e}")
            bad += 1
            continue
    match = hashlib.sha256(open(path, "rb").read()).hexdigest() == r.sha256
    ok += match
    bad += not match
    if not match:
        print(f"HASH MISMATCH  {r.file} (source may have been regenerated since our download)")
print(f"{ok} files verified, {bad} problems, {skipped} rows rebuilt by the pipeline instead")
