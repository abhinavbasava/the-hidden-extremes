"""Shared context builder: ONE implementation of neighbors, IDW, plume and weather.

07_context.py (AI inputs) and 12_contextual_comparator.py (the conventional
regression) both import this file, so the AI and the comparator see inputs
built by identical code. Any rule change here applies to both.

Rules:
  neighbors  5 nearest OTHER EPA sites 10-150 km away reporting that day
             (leave-one-site-out); stored rounded (km 0.1, PM2.5 0.01)
  idw        inverse-distance-weighted (power 2) mean of those rounded values
  plume      densest NOAA HMS polygon over the point (0 none .. 3 Heavy)
  weather    NOAA ISD-Lite hourly data from the nearest station within 50 km,
             aggregated over EPA's local-standard-time day; >= 18 valid hours
"""
import gzip
import hashlib
import os
import time
import urllib.request
import zipfile
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import geopandas as gpd
import numpy as np
import pandas as pd
from shapely.geometry import Point
from timezonefinder import TimezoneFinder

MIN_KM, MAX_KM, K, WX_KM, MIN_HOURS = 10, 150, 5, 50, 18
HMS_URL = "https://satepsanone.nesdis.noaa.gov/pub/FIRE/web/HMS/Smoke_Polygons/Shapefile/{y}/{m}/hms_smoke{ymd}.zip"
ISD_URL = "https://noaa-isd-pds.s3.amazonaws.com/isd-lite/data/{y}/{usaf}-{wban}-{y}.gz"
RANK = {"Light": 1, "Medium": 2, "Heavy": 3}
NAMES = {0: "none", 1: "Light", 2: "Medium", 3: "Heavy"}
COMPASS = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def km(lat1, lon1, lat2, lon2):
    p = np.pi / 180
    a = (np.sin((lat2 - lat1) * p / 2) ** 2 +
         np.cos(lat1 * p) * np.cos(lat2 * p) * np.sin((lon2 - lon1) * p / 2) ** 2)
    return 12742 * np.arcsin(np.sqrt(a))


def compass(deg):
    return COMPASS[int((deg + 22.5) // 45) % 8]


def bearing(lat1, lon1, lat2, lon2):
    p = np.pi / 180
    y = np.sin((lon2 - lon1) * p) * np.cos(lat2 * p)
    x = np.cos(lat1 * p) * np.sin(lat2 * p) - np.sin(lat1 * p) * np.cos(lat2 * p) * np.cos((lon2 - lon1) * p)
    return compass((np.degrees(np.arctan2(y, x)) + 360) % 360)


def neighbors(day, site, lat, lon):
    """day = all site-days for one date. Returns (neighbor list, idw)."""
    d = day[day.site != site].copy()
    d["dist"] = km(lat, lon, d.lat.values, d.lon.values)
    nb = d[(d.dist >= MIN_KM) & (d.dist <= MAX_KM)].nsmallest(K, "dist")
    out = [{"site_id": n.site,
            "name": str(n.site_name).strip() if pd.notna(n.site_name) else f"EPA site {n.site}",
            "state": n.state, "lat": round(n.lat, 5), "lon": round(n.lon, 5),
            "km": round(n.dist, 1), "direction": bearing(lat, lon, n.lat, n.lon),
            "pm25": round(n.pm25, 2)} for n in nb.itertuples()]
    if not out:
        return out, None
    dk = np.array([n["km"] for n in out])
    v = np.array([n["pm25"] for n in out])
    return out, float(np.sum(v / dk ** 2) / np.sum(1 / dk ** 2))


class Context:
    def __init__(self, isd_path, cache):
        self.cache = cache
        os.makedirs(cache, exist_ok=True)
        self.sources = {}
        self._hms, self._isd = {}, {}
        self.tzf = TimezoneFinder()
        isd = pd.read_csv(isd_path, dtype=str)
        isd = isd[(isd.CTRY == "US") & isd.LAT.notna() & isd.LON.notna()]
        isd["lat"], isd["lon"] = isd.LAT.astype(float), isd.LON.astype(float)
        self.isd = isd[isd.lat != 0].rename(columns={"STATION NAME": "stname"})
        self.log(isd_path, "https://www.ncei.noaa.gov/pub/data/noaa/isd-history.csv")

    def log(self, path, url):
        if path not in self.sources:
            self.sources[path] = {"file": os.path.basename(path), "url": url, "sha256": sha(path)}

    def fetch(self, url, path):
        if not os.path.exists(path):
            for _ in range(3):
                try:
                    data = urllib.request.urlopen(url, timeout=60).read()
                    open(path, "wb").write(data)
                    break
                except Exception:
                    time.sleep(2)
            else:
                return None
        self.log(path, url)
        return path

    # ---------- plume ----------
    def _plumes(self, date):
        if date not in self._hms:
            ymd = date.replace("-", "")
            zp = self.fetch(HMS_URL.format(y=ymd[:4], m=ymd[4:6], ymd=ymd),
                            os.path.join(self.cache, f"hms_smoke{ymd}.zip"))
            g = None
            if zp is not None:
                with zipfile.ZipFile(zp) as z:
                    shp = [n for n in z.namelist() if n.endswith(".shp")][0]
                g = gpd.read_file(f"zip://{zp}!{shp}")
                g = (g.set_crs(4326) if g.crs is None else g).to_crs(4326)
            self._hms[date] = g
        return self._hms[date]

    def plume(self, date, lat, lon):
        g = self._plumes(date)
        if g is None:
            return None
        hit = g[g.contains(Point(lon, lat))]
        if not len(hit):
            return 0
        return max(RANK.get(str(v).strip().title(), 1) for v in hit["Density"])

    # ---------- weather ----------
    def lst_window(self, date, lat, lon):
        tz = ZoneInfo(self.tzf.timezone_at(lng=lon, lat=lat))
        std = tz.utcoffset(datetime(int(date[:4]), 1, 15))  # January = standard time
        start = datetime.fromisoformat(date) - std
        return start, start + timedelta(hours=24), std.total_seconds() / 3600

    def _station_year(self, usaf, wban, y):
        k = (usaf, wban, y)
        if k not in self._isd:
            p = self.fetch(ISD_URL.format(y=y, usaf=usaf, wban=wban),
                           os.path.join(self.cache, f"isdlite_{usaf}-{wban}-{y}.gz"))
            w = None
            if p is not None:
                cols = ["y", "m", "d", "h", "temp", "dewp", "slp", "wdir", "wspd", "sky", "p1", "p6"]
                w = pd.read_csv(gzip.open(p, "rt"), sep=r"\s+", header=None, names=cols)
                w["t"] = pd.to_datetime(dict(year=w.y, month=w.m, day=w.d, hour=w.h))
                w = w.replace(-9999, np.nan).drop_duplicates("t")
            self._isd[k] = w
        return self._isd[k]

    def weather(self, date, lat, lon):
        start, end, offset = self.lst_window(date, lat, lon)
        y = date[:4]
        st = self.isd[(self.isd.BEGIN <= f"{y}0101") & (self.isd.END >= f"{y}1231")]
        st = st.assign(dist=km(lat, lon, st.lat.values, st.lon.values))
        st = st[st.dist <= WX_KM].sort_values("dist")
        for s in st.itertuples():
            wall = self._station_year(s.USAF, s.WBAN, y)
            if wall is None:
                continue
            w = wall[(wall.t >= start) & (wall.t < end)]
            if w.temp.notna().sum() < MIN_HOURS:
                continue
            c2f = lambda c: round(c / 10 * 9 / 5 + 32, 1)
            ws = w.wspd / 10 * 1.94384  # m/s x10 -> knots
            vec = w[(w.wspd > 0) & w.wdir.between(0, 360)]
            if len(vec) >= 6:
                u = -(vec.wspd * np.sin(np.radians(vec.wdir))).sum()
                v = -(vec.wspd * np.cos(np.radians(vec.wdir))).sum()
                wdir = compass((np.degrees(np.arctan2(-u, -v)) + 360) % 360)
            else:
                wdir = "calm or variable" if (w.wspd == 0).sum() >= 12 else None
            if w.p1.notna().sum() >= MIN_HOURS:
                precip, psrc = round(w.p1.where(w.p1 >= 0, 0).sum() / 10 / 25.4, 2), "1-hour reports"
            else:  # 6-hour totals whose period ENDS inside the window (shifted up to 3 h)
                r6 = wall[(wall.t > start) & (wall.t <= end) & (wall.t.dt.hour % 6 == 0) & wall.p6.notna()]
                if len(r6) >= 3:
                    precip = round(r6.p6.where(r6.p6 >= 0, 0).sum() / 10 / 25.4, 2)
                    psrc = f"{len(r6)} six-hour reports (approximate window)"
                else:
                    precip, psrc = None, None
            dp = w.dewp.mean()
            return {"station_id": f"{s.USAF}-{s.WBAN}", "station": str(s.stname).strip(),
                    "station_km": round(s.dist, 1), "utc_offset_std": offset,
                    "window_utc": f"{start:%Y-%m-%dT%H}Z/{end:%Y-%m-%dT%H}Z",
                    "temp_hours": int(w.temp.notna().sum()), "wind_hours": int(w.wspd.notna().sum()),
                    "temp_mean_f": c2f(w.temp.mean()), "temp_max_f": c2f(w.temp.max()),
                    "temp_min_f": c2f(w.temp.min()), "dewpoint_f": c2f(dp) if pd.notna(dp) else None,
                    "wind_mean_kt": round(ws.mean(), 1) if ws.notna().any() else None,
                    "wind_max_kt": round(ws.max(), 1) if ws.notna().any() else None,
                    "wind_dir_vector_mean": wdir, "precip_in": precip, "precip_source": psrc}
        return None

    def manifest(self):
        return pd.DataFrame(self.sources.values()).sort_values("file")
