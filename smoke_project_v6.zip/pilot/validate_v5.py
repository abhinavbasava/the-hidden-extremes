"""Independent pre/postflight validator (written by the ChatGPT audit for v4; updated for v5:
five conditions, input-file hash, counts derived from the data). Does not modify data or call AI."""
import argparse, hashlib, json, math, re, sys
from pathlib import Path
import numpy as np
import pandas as pd
ARMS={'arm_a','arm_n','arm_n_masked','arm_b','arm_b_masked'}
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(ok,msg):
    if not bool(ok): raise ValueError(msg)
def parse(s):
    try:
        v=float(json.loads(re.search(r'\{.*\}',str(s),re.S).group(0))['pm25_ug_m3'])
        return v if math.isfinite(v) and v>=0 else None
    except Exception: return None
def validate(root, run=None, allow_mock=False, repeats=3):
    root=Path(root); inputs=pd.read_csv(root/'pilot_inputs.csv',dtype={'target_id':str,'site':str}); key=pd.read_csv(root/'scoring_key.csv'); p=pd.DataFrame([json.loads(s) for s in (root/'prompts.jsonl').read_text().splitlines()]); ids=set(inputs.target_id)
    need(len(inputs)==50 and inputs.target_id.is_unique,'expected 50 unique input targets'); need(key.target_id.is_unique and set(key.target_id)==ids,'scoring key target mismatch'); need(np.isfinite(key.truth_pm25).all() and (key.truth_pm25>=0).all(),'invalid reference value'); need(not {'truth_pm25','stratum','baseline_idw'} & set(inputs.columns),'truth or label fields in input'); need(not p.duplicated(['target_id','generation_condition']).any(),'duplicate prompt key'); need(set(zip(p.target_id,p.generation_condition))=={(i,a) for i in ids for a in ARMS},'prompt Cartesian product mismatch'); need(all(hashlib.sha256(s.encode()).hexdigest()==h for s,h in zip(p.prompt,p.prompt_sha256)),'prompt text hash mismatch'); need(p.prompt_sha256.is_unique,'duplicate prompt text'); need(inputs.date.str.startswith('2020-').all(),'non-pilot date');
    k=key.set_index('target_id'); lookup=p.set_index(['target_id','generation_condition']);
    for r in inputs.itertuples():
        ctx=json.loads(r.context_json); nb=ctx['neighbors']; d=np.array([n['km'] for n in nb]); v=np.array([n['pm25'] for n in nb]); need(3<=len(nb)<=5 and len({n['site_id'] for n in nb})==len(nb),f'{r.target_id}: invalid neighbor count or duplicate'); need(all(n['site_id']!=r.site for n in nb) and np.isfinite(d).all() and ((d>=10)&(d<=150)).all(),f'{r.target_id}: invalid neighbors'); need(np.isfinite(v).all() and (v>=0).all(),f'{r.target_id}: invalid neighbor values'); need(abs(np.average(v,weights=d**-2)-k.loc[r.target_id,'baseline_idw'])<=0.000501,f'{r.target_id}: IDW mismatch'); need(all(r.site not in lookup.loc[(r.target_id,a),'prompt'] for a in ARMS),f'{r.target_id}: target site ID in prompt')
    print(f'PREFLIGHT PASS: {len(ids)} targets, {len(p)} unique prompts, hashes, dates, neighbor rules and IDW arithmetic')
    if run is None: return
    run=Path(run); m=json.loads(Path(str(run)+'.manifest.json').read_text()); g=pd.read_csv(run,keep_default_na=False); need(m['prompts_sha256']==sha(root/'prompts.jsonl'),'manifest prompt hash mismatch'); need(m['script_sha256']==sha(root/'09_generate.py'),'generator script hash mismatch'); need(m['repeats']==repeats,'manifest repeat count mismatch'); need(m.get('inputs_sha256')==sha(root/'pilot_inputs.csv'),'manifest inputs hash mismatch');
    cols=['target_id','generation_condition','repeat']; expected={(i,a,r) for i in ids for a in ARMS for r in range(1,repeats+1)}; need(not g.duplicated(cols).any() and set(g[cols].itertuples(index=False,name=None))==expected,'exact generation key set mismatch');
    for col,val in [('provider',m['provider']),('requested_model',m['model']),('temperature',m['temperature']),('max_tokens',m['max_tokens']),('is_mock',m['is_mock'])]: need((g[col]==val).all(),f'manifest/row mismatch: {col}')
    need(allow_mock or not m['is_mock'],'mock records refused'); need(g.returned_model.nunique()==1 and bool(str(g.returned_model.iloc[0]).strip()),'missing or mixed returned models'); need(g.record_id.is_unique,'duplicate record IDs'); joined=g.merge(p[['target_id','generation_condition','prompt_sha256']],on=cols[:2],validate='many_to_one',suffixes=('','_expected')); need((joined.prompt_sha256==joined.prompt_sha256_expected).all(),'row prompt hash mismatch');
    for r in g.itertuples():
        v=parse(r.raw_response); need(r.parse_ok==(v is not None),f'{r.record_id}: parse flag disagrees with raw response'); need((r.ai_pm25_ug_m3=='' if v is None else math.isclose(float(r.ai_pm25_ug_m3),v,rel_tol=1e-12,abs_tol=1e-12)),f'{r.record_id}: numeric response mismatch')
    fail=g.groupby('generation_condition').parse_ok.apply(lambda s:1-s.mean()); print(f'POSTFLIGHT PASS: exact {len(expected)}-row grid, manifest, model, hashes, raw response consistency'); print('Parse failure rates:',fail.to_dict()); need((fail<.05).all(),'pilot go/no-go failed: parse failure >=5%')
    if m['is_mock']: print('MOCK ONLY: no evidence about real AI.')
if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('pilot_dir'); ap.add_argument('--run'); ap.add_argument('--allow-mock',action='store_true'); ap.add_argument('--repeats',type=int,default=3); a=ap.parse_args()
    try: validate(a.pilot_dir,a.run,a.allow_mock,a.repeats)
    except (ValueError,KeyError,TypeError,FileNotFoundError) as e: sys.exit('REFUSED: '+str(e))
