"""Step 9: send every prompt to the AI model and log everything.

Reads only prompts.jsonl and pilot_inputs.csv. It never sees truth.

Each prompt goes in its own fresh request (no chat history). Every response is
saved raw, then parsed. A response that does not parse stays in the file with
parse_ok = False and is never silently retried: a model that fails to answer is
itself a result. A request that gets NO response after 3 network tries stops
the run so it can be resumed later; nothing fake is written for it.

Run manifest: the first run writes <out>.manifest.json (provider, model,
settings, SHA-256 of the prompts file, the inputs file and this script). A resumed run must
match it exactly, or the script refuses. Mock and real rows can never mix.

Per record it logs: requested and returned model, provider request ID, stop
reason, input/output tokens, number of attempts, full prompt SHA-256 and UTC
timestamp. API keys come from environment variables and are never written.

Providers:
  anthropic  needs ANTHROPIC_API_KEY
  openai     needs OPENAI_API_KEY
  mock       NO AI. Returns neighbor IDW plus noise to test the code. Rows carry
             is_mock = True and 10_score.py refuses them unless --allow-mock.

Usage: python 09_generate.py prompts.jsonl pilot_inputs.csv generations.csv
           --provider anthropic --model <exact model id> --repeats 3 [--temperature 1.0]
"""
import argparse
import datetime as dt
import hashlib
import json
import os
import re
import sys
import time
import urllib.request

import numpy as np
import pandas as pd

ap = argparse.ArgumentParser()
ap.add_argument("prompts")
ap.add_argument("inputs")
ap.add_argument("out")
ap.add_argument("--provider", required=True, choices=["anthropic", "openai", "mock"])
ap.add_argument("--model", required=True)
ap.add_argument("--repeats", type=int, default=3)
ap.add_argument("--temperature", type=float, default=1.0)
ap.add_argument("--max_tokens", type=int, default=200)
ap.add_argument("--order-seed", type=int, default=2026)
a = ap.parse_args()


def sha_file(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


manifest = {"provider": a.provider, "model": a.model, "temperature": a.temperature,
            "max_tokens": a.max_tokens, "repeats": a.repeats, "order_seed": a.order_seed,
            "prompts_sha256": sha_file(a.prompts), "inputs_sha256": sha_file(a.inputs),
            "script_sha256": sha_file(__file__),
            "is_mock": a.provider == "mock"}
mpath = a.out + ".manifest.json"
if os.path.exists(a.out) and not os.path.exists(mpath):
    sys.exit(f"REFUSED: {a.out} exists with no manifest. Start a new output file.")
if os.path.exists(mpath):
    old = json.load(open(mpath))
    diff = {k: (old.get(k), v) for k, v in manifest.items() if old.get(k) != v}
    if diff:
        sys.exit(f"REFUSED: settings differ from the existing run: {diff}. Use a new output file.")
else:
    json.dump({**manifest, "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")},
              open(mpath, "w"), indent=2)


def post(url, headers, body):
    req = urllib.request.Request(url, json.dumps(body).encode(), {**headers, "content-type": "application/json"})
    for attempt in range(1, 4):
        try:
            return json.loads(urllib.request.urlopen(req, timeout=120).read()), attempt
        except Exception as e:
            err = e
            time.sleep(5 * attempt)
    sys.exit(f"STOPPED: no response after 3 tries ({err}). Rerun the same command to resume.")


def call(prompt, inp, rng):
    if a.provider == "anthropic":
        r, n = post("https://api.anthropic.com/v1/messages",
                    {"x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01"},
                    {"model": a.model, "max_tokens": a.max_tokens, "temperature": a.temperature,
                     "messages": [{"role": "user", "content": prompt}]})
        return {"raw_response": "".join(b.get("text", "") for b in r.get("content", [])),
                "returned_model": r.get("model"), "request_id": r.get("id"), "stop_reason": r.get("stop_reason"),
                "input_tokens": r.get("usage", {}).get("input_tokens"),
                "output_tokens": r.get("usage", {}).get("output_tokens"), "attempts": n}
    if a.provider == "openai":
        r, n = post("https://api.openai.com/v1/chat/completions",
                    {"authorization": f"Bearer {os.environ['OPENAI_API_KEY']}"},
                    {"model": a.model, "max_completion_tokens": a.max_tokens, "temperature": a.temperature,
                     "messages": [{"role": "user", "content": prompt}]})
        ch = r["choices"][0]
        return {"raw_response": ch["message"].get("content") or "", "returned_model": r.get("model"),
                "request_id": r.get("id"), "stop_reason": ch.get("finish_reason"),
                "input_tokens": r.get("usage", {}).get("prompt_tokens"),
                "output_tokens": r.get("usage", {}).get("completion_tokens"), "attempts": n}
    # mock: arm_a gets a flat guess; the other arms follow the neighbor IDW from the inputs
    nb = json.loads(inp.context_json)["neighbors"]
    d, v = np.array([n["km"] for n in nb]), np.array([n["pm25"] for n in nb])
    base = 12.0 if "Information available" not in prompt else float(np.sum(v / d ** 2) / np.sum(1 / d ** 2))
    return {"raw_response": json.dumps({"pm25_ug_m3": round(base * float(rng.lognormal(0, 0.35)), 1)}),
            "returned_model": "mock", "request_id": None, "stop_reason": "mock",
            "input_tokens": None, "output_tokens": None, "attempts": 1}


def parse(text):
    try:
        v = float(json.loads(re.search(r"\{.*\}", text, re.S).group(0))["pm25_ug_m3"])
        return (v, True) if np.isfinite(v) and v >= 0 else (None, False)
    except Exception:
        return None, False


inputs = pd.read_csv(a.inputs).set_index("target_id")
prompts = [json.loads(line) for line in open(a.prompts)]
rng = np.random.default_rng(7)
done = set()
if os.path.exists(a.out):
    prev = pd.read_csv(a.out)
    done = set(zip(prev.target_id, prev.generation_condition, prev["repeat"]))

buf = []


def flush():
    global buf
    if buf:
        pd.DataFrame(buf).to_csv(a.out, mode="a", header=not os.path.exists(a.out), index=False)
        buf = []


# Randomized request order (fixed by --order-seed, recorded in the manifest), so
# conditions and repeats are interleaved over the run and any drift in the
# provider's service during the run cannot line up with one condition.
jobs = [(rep, p) for rep in range(1, a.repeats + 1) for p in prompts]
order = np.random.default_rng(a.order_seed).permutation(len(jobs))
try:
    for pos, idx in enumerate(order):
        rep, p = jobs[idx]
        if (p["target_id"], p["generation_condition"], rep) in done:
            continue
        inp = inputs.loc[p["target_id"]]
        res = call(p["prompt"], inp, rng)
        v, ok = parse(res["raw_response"])
        buf.append({"record_id": f"{p['target_id']}_{p['generation_condition']}_r{rep}",
                    "target_id": p["target_id"], "site": inp.site, "site_name": inp.site_name,
                    "state": inp.state, "region": inp.region, "lat": inp.lat, "lon": inp.lon,
                    "date": inp.date, "generation_condition": p["generation_condition"], "repeat": rep,
                    "request_index": pos,
                    "ai_pm25_ug_m3": v, "parse_ok": ok, **res,
                    "provider": a.provider, "requested_model": a.model, "temperature": a.temperature,
                    "max_tokens": a.max_tokens, "prompt_sha256": p["prompt_sha256"],
                    "generated_at_utc": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
                    "is_mock": a.provider == "mock"})
        if len(buf) >= 25:
            flush()
finally:
    flush()

g = pd.read_csv(a.out)
print(len(g), "records |", int((~g.parse_ok).sum()), "failed to parse |",
      "returned models:", g.returned_model.value_counts().to_dict())
