"""Step 11: self-test. Proves the scorer and the independent validator refuse bad runs.

Generates a mock run in a temp folder, confirms both checkers accept it (in
mock-test mode), then applies seven corruptions and confirms the checkers refuse each:
  1 unknown target substituted        4 an AI value altered (raw unchanged)
  2 an entire repeat removed          5 mock scored without --allow-mock
  3 a second returned model           6 resume with different settings
  7 scoring key edited after it was frozen (scorer only; the key is not the validator's job)
Run it after any code change. No AI calls; mock output never leaves the temp folder.

Usage: python 11_selftest.py   (run inside the pilot folder)
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile

import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
tmp = tempfile.mkdtemp()
gen = os.path.join(tmp, "gen.csv")


def run(args):
    return subprocess.run([sys.executable, "-I", *args], cwd=HERE, capture_output=True, text=True)


def score(path, mock=True, key="scoring_key.csv"):
    return run(["10_score.py", key, path, "prompts.jsonl", os.path.join(tmp, "s.csv")]
               + (["--allow-mock"] if mock else []))


def validate(path, mock=True):
    return run(["validate_v5.py", ".", "--run", path] + (["--allow-mock"] if mock else []))


def variant(name, edit):
    p = os.path.join(tmp, f"{name}.csv")
    g = pd.read_csv(gen)
    edit(g)
    g.to_csv(p, index=False)
    shutil.copy(gen + ".manifest.json", p + ".manifest.json")
    return p


r = run(["09_generate.py", "prompts.jsonl", "pilot_inputs.csv", gen, "--provider", "mock", "--model", "mock"])
assert r.returncode == 0, r.stderr
results = []
ok_s, ok_v = score(gen), validate(gen)
results.append(("clean mock run is accepted", ok_s.returncode == 0 and ok_v.returncode == 0))


def swap_target(g):
    g.loc[0, "target_id"] = "P999"


def drop_repeat(g):
    g.drop(g.index[g["repeat"] == 3], inplace=True)


def second_model(g):
    g.loc[5, "returned_model"] = "other-model"


def alter_value(g):
    g.loc[7, "ai_pm25_ug_m3"] = g.loc[7, "ai_pm25_ug_m3"] + 50


for name, edit in [("unknown target", swap_target), ("repeat removed", drop_repeat),
                   ("second returned model", second_model), ("value altered", alter_value)]:
    p = variant(name.replace(" ", "_"), edit)
    results.append((f"{name}: scorer refuses", score(p).returncode != 0))
    results.append((f"{name}: validator refuses", validate(p).returncode != 0))
results.append(("mock without --allow-mock: scorer refuses", score(gen, mock=False).returncode != 0))
results.append(("mock without --allow-mock: validator refuses", validate(gen, mock=False).returncode != 0))
r = run(["09_generate.py", "prompts.jsonl", "pilot_inputs.csv", gen, "--provider", "mock", "--model", "mock",
         "--temperature", "0.2"])
results.append(("resume with different settings: generator refuses", r.returncode != 0))

k = pd.read_csv(os.path.join(HERE, "scoring_key.csv"))
k.loc[0, "truth_pm25"] += 1
k.to_csv(os.path.join(tmp, "edited_key.csv"), index=False)
results.append(("scoring key edited after freeze: scorer refuses",
                score(gen, key=os.path.join(tmp, "edited_key.csv")).returncode != 0))

shutil.rmtree(tmp)
for name, passed in results:
    print(("PASS  " if passed else "FAIL  ") + name)
print(f"\n{sum(p for _, p in results)}/{len(results)} checks passed")
sys.exit(0 if all(p for _, p in results) else 1)
